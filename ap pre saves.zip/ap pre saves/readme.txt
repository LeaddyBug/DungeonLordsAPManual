pre made save files of each race.
just simple qol stuff starting you off with a high 'inspect' level so chests aren't too awful to open
and a few points into 'scout' so you can actually push buttons
starting class has been removed so the only classes you can have are the first 5 you find
will probably be adding more qol stuff eventually once things get more hammered out
no advancement points were used so you can still set your starting skills however you want